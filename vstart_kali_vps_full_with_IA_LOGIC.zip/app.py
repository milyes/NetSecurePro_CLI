
from flask import Flask, render_template_string, request
import subprocess

app = Flask(__name__)
HTML = open("IA_DZROUGE_TERMINal.html", encoding='utf-8').read()

@app.route("/", methods=["GET"])
def index():
    return render_template_string(HTML)

@app.route("/run", methods=["POST"])
def run_logic():
    subprocess.Popen(["bash", "IA_L0GIC_universel.multiclass.sh"])
    return "✅ Script IA_LOGIC lancé avec succès."

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
