#!/bin/bash

# === Activation automatique de l'environnement virtuel ===
VENV_DIR="$(dirname "$0")/../venv"
if [ -f "$VENV_DIR/bin/activate" ]; then
    source "$VENV_DIR/bin/activate"
    echo "✅ Environnement virtuel activé automatiquement."
else
    echo "⚠️ Aucun environnement virtuel trouvé à $VENV_DIR"
    exit 1
fi

# === MENU CLI ===
echo "📦 NetSecurePro VPS Starter"
echo "1. Démarrer un serveur Flask"
echo "2. Démarrer un serveur FastAPI"
read -p "➡️ Choisissez une option [1/2] : " CHOICE

# === CONFIGURATION ===
PORT=5001
CLOUDFLARE_LOG="cloudflare_url.log"

if [[ "$CHOICE" == "1" ]]; then
    APP_TYPE="flask"
    FLASK_FILE="flask_app/app.py"
elif [[ "$CHOICE" == "2" ]]; then
    APP_TYPE="fastapi"
    FASTAPI_MODULE="fastapi_app.main:app"
else
    echo "❌ Choix invalide."
    exit 1
fi

# === INSTALLATION DES DÉPENDANCES ===
echo "🔧 Vérification des dépendances..."
pip install --upgrade flask fastapi uvicorn

# === DÉTECTION IP LOCALE ===
IP_LOCAL=$(hostname -I | awk '{print $1}')
echo "📡 IP locale : http://$IP_LOCAL:$PORT"

# === LANCEMENT DU SERVEUR ===
if [[ "$APP_TYPE" == "flask" ]]; then
    echo "🚀 Lancement Flask..."
    export FLASK_APP=$FLASK_FILE
    nohup flask run --host=0.0.0.0 --port=$PORT > flask.log 2>&1 &
elif [[ "$APP_TYPE" == "fastapi" ]]; then
    echo "🚀 Lancement FastAPI..."
    nohup uvicorn $FASTAPI_MODULE --host 0.0.0.0 --port $PORT > fastapi.log 2>&1 &
fi

sleep 3

# === CLOUD FLARE ===
echo "🌐 Tunnel Cloudflare..."
nohup cloudflared tunnel --url http://localhost:$PORT > $CLOUDFLARE_LOG 2>&1 &

sleep 5

CF_URL=$(grep -oE "https://[-a-zA-Z0-9@:%._\+~#=]{1,256}\.trycloudflare\.com" $CLOUDFLARE_LOG | head -n 1)
if [[ -n "$CF_URL" ]]; then
    echo "🌍 URL publique : $CF_URL"
else
    echo "⚠️ URL Cloudflare non trouvée."
fi
