# ✅ NetSecurePro Installer Full

Ce pack contient :
- 📱 NetSecurePro_Web_CLI_REAL.apk : Application Android IA WebView
- 💽 netsecurepro_web_cli_REAL.deb : Application Ubuntu installable
- 🧩 netsecurepro_web_cli_REAL.AppImage : App portable pour Linux
- 🧠 install_netsecurepro.sh : Script d'installation complet (Linux)
- 🖼 splash_final.png : Splash officiel

Utilisation :
1. `chmod +x install_netsecurepro.sh`
2. `./install_netsecurepro.sh`
3. Lancez `./webview_ia_launcher.sh` pour démarrer l’interface
