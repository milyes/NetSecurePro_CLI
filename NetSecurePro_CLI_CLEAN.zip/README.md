# NetSecurePro_CLI

Lanceur CLI interactif pour démarrer un serveur Flask ou FastAPI avec tunnel Cloudflare.

## Étapes

1. Créer et activer un environnement virtuel :

```bash
python3 -m venv venv
source venv/bin/activate
```

2. Lancer le script :

```bash
chmod +x vstart_kali_vps.sh
./vstart_kali_vps.sh
```

Un menu s'affichera pour choisir le type de serveur.
