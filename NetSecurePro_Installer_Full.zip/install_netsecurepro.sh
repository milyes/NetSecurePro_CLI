#!/bin/bash
echo "🔧 Installation de NetSecurePro Web CLI IA..."
mkdir -p ~/NetSecurePro_CLI
cp -r * ~/NetSecurePro_CLI
cd ~/NetSecurePro_CLI
echo "✅ Fichiers copiés."
chmod +x webview_ia_launcher.sh
echo "🧠 Lancement avec ./webview_ia_launcher.sh"
