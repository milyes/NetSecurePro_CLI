import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(NetSecureProApp());
}

class NetSecureProApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NetSecurePro Web CLI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.red,
      ),
      home: WebCLIScreen(),
    );
  }
}

class WebCLIScreen extends StatefulWidget {
  @override
  _WebCLIScreenState createState() => _WebCLIScreenState();
}

class _WebCLIScreenState extends State<WebCLIScreen> {
  late WebViewController _controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NetSecurePro Web CLI'),
      ),
      body: Stack(
        children: [
          WebView(
            initialUrl: 'https://dzrouge.trycloudflare.com',
            javascriptMode: JavascriptMode.unrestricted,
            onWebViewCreated: (controller) {
              _controller = controller;
            },
          ),
          Positioned(
            bottom: 80,
            right: 20,
            child: FloatingActionButton(
              backgroundColor: Colors.red,
              child: Icon(Icons.smart_toy),
              onPressed: () {
                _controller.runJavascript("alert('Assistant IA activé 🚀');");
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        color: Colors.black,
        padding: EdgeInsets.all(10),
        child: Center(
          child: GestureDetector(
            onTap: () => _controller.loadUrl('https://linkedin.com/in/milyes'),
            child: Text(
              '🔗 Profil LinkedIn : milyes',
              style: TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
        ),
      ),
    );
  }
}
