# NetSecurePro IA rList

💡 Application IA mobile avec interface WebView intégrée.

## 🔹 Fonctionnalités

- WebView locale (offline) pour IA interactive
- Fallback online vers GitHub Pages
- Scripts d'analyse IA (`scan`, `résumé`, `test`)
- APK Android autonome
- QR code d'installation rapide

## 📲 Installation

1. Télécharger `NetSecurePro_IA_rList.apk`
2. Lancer sur Android
3. Ou scanner le QR code fourni

## 🔗 Liens

- [Installation APK](https://milyes.github.io/NetSecurePro-IA-rList)
