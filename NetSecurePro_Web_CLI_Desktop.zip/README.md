# NetSecurePro Web CLI (Desktop)

Cette application Flutter Desktop (Ubuntu/Linux) charge automatiquement :

🌐 `https://dzrouge.trycloudflare.com`  
✅ Avec bouton IA flottant  
🔗 Lien LinkedIn intégré  
🎨 Thème sombre rouge

## Installation

```bash
flutter pub get
flutter run -d linux
```
